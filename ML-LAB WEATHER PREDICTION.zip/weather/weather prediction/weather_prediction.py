import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

class WeatherPredictor:
    def __init__(self):
        self.model = GaussianNB()
        self.label_encoder = LabelEncoder()
        
    def load_data(self, csv_path='weather_dataset_1000.csv'):
        """Load weather data from CSV file"""
        try:
            data = pd.read_csv(csv_path)
            required_columns = ['Temperature', 'Humidity', 'Pressure', 'WindSpeed', 'Condition']
            
            # Check if all required columns exist
            missing_columns = [col for col in required_columns if col not in data.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            return data
        except Exception as e:
            print(f"Error loading data: {str(e)}")
            return None
    
    def prepare_data(self, data):
        """Prepare data for training"""
        X = data[['Temperature', 'Humidity', 'Pressure', 'WindSpeed']]
        y = self.label_encoder.fit_transform(data['Condition'])
        return X, y
    
    def train(self, X, y):
        """Train the Naive Bayes model"""
        self.model.fit(X, y)
    
    def predict(self, features):
        """Predict weather condition"""
        prediction = self.model.predict(features)
        return self.label_encoder.inverse_transform(prediction)
    
    def plot_feature_importance(self, X, y, data):
        """Plot feature distributions for each weather condition"""
        features = ['Temperature', 'Humidity', 'Pressure', 'WindSpeed']
        conditions = self.label_encoder.inverse_transform(np.unique(y))
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.ravel()
        
        for idx, feature in enumerate(features):
            for condition in conditions:
                condition_mask = data['Condition'] == condition
                axes[idx].hist(X[feature][condition_mask], 
                             alpha=0.5, 
                             label=condition, 
                             bins=20)
            axes[idx].set_title(f'{feature} Distribution by Weather Condition')
            axes[idx].set_xlabel(feature)
            axes[idx].set_ylabel('Frequency')
            axes[idx].legend()
        
        plt.tight_layout()
        plt.savefig('weather_feature_distributions.png')
        plt.close()

if __name__ == "__main__":
    # Initialize predictor
    predictor = WeatherPredictor()
    
    # Load data from CSV
    data = predictor.load_data()
    
    if data is not None:
        # Print dataset information
        print("\nDataset Information:")
        print(f"Total records: {len(data)}")
        print("\nWeather Conditions Distribution:")
        print(data['Condition'].value_counts())
        print("\nFeature Statistics:")
        print(data.describe())
        
        # Prepare data
        X, y = predictor.prepare_data(data)
        
        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train the model
        predictor.train(X_train, y_train)
        
        # Make predictions on test set
        y_pred = predictor.predict(X_test)
        
        # Print model performance
        print("\nModel Performance:")
        print("Accuracy:", accuracy_score(predictor.label_encoder.transform(y_pred), y_test))
        print("\nClassification Report:")
        print(classification_report(y_test, predictor.label_encoder.transform(y_pred)))
        
        # Plot feature distributions
        predictor.plot_feature_importance(X, y, data)
        
        # Interactive prediction
        while True:
            try:
                print("\nEnter weather features for prediction (or 'q' to quit):")
                temp = input("Temperature (°C): ")
                if temp.lower() == 'q':
                    break
                    
                humidity = input("Humidity (%): ")
                pressure = input("Pressure (hPa): ")
                wind_speed = input("Wind Speed (km/h): ")
                
                features = np.array([[float(temp), float(humidity), float(pressure), float(wind_speed)]])
                prediction = predictor.predict(features)
                
                print(f"\nPredicted weather condition: {prediction[0]}")
                
            except ValueError:
                print("Please enter valid numerical values.")
            except Exception as e:
                print(f"An error occurred: {str(e)}") 