# Weather Condition Prediction using Naive Bayesian Network

This project implements a weather condition prediction system using a Naive Bayesian classifier. The system predicts weather conditions (Sunny, Rainy, Cold, Thunderstorm, or Cloudy) based on various meteorological features.

## Features Used
- Temperature (°C)
- Humidity (%)
- Atmospheric Pressure (hPa)
- Wind Speed (km/h)

## Requirements
- Python 3.7+
- NumPy
- Pandas
- Scikit-learn
- Matplotlib

## Installation

1. Clone this repository
2. Install the required packages:
```bash
pip install -r requirements.txt
```

## Usage

Run the main script:
```bash
python weather_prediction.py
```

The script will:
1. Generate sample weather data
2. Train a Naive Bayes model
3. Evaluate the model's performance
4. Create visualizations of feature distributions
5. Show an example prediction

## Output
- Model performance metrics (accuracy and classification report)
- Feature distribution plots saved as 'weather_feature_distributions.png'
- Example prediction for specific weather conditions

## Model Details
The system uses a Gaussian Naive Bayes classifier, which assumes that the features follow a normal distribution. The model is trained on synthetic data that simulates realistic weather patterns.

## Note
This implementation uses synthetic data for demonstration purposes. For real-world applications, you should replace the `create_sample_data()` method with actual historical weather data. 